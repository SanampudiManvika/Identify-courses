package pageobjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

public class BasePage {//This is parent class of all page objects

	public WebDriver driver;//Instead of writing webdriver for every class we can separate base class and we can reuse it by using extends 

	public BasePage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

}
