package com.testcase;

import java.io.IOException;

import org.testng.annotations.Test;

import pageobjects.EnterprisePage;
import pageobjects.HomePage;
import pageobjects.Language_Learning;
import testBase.BaseTest;

public class TC_003_CourseDetails extends BaseTest {

	@Test(priority = 3)
	public void ClickForEnterprise() {
		EnterprisePage ep = new EnterprisePage(driver);
		logger.info("Launching  Enterprise page");
		ep.clickForEnterpriseLink();
		logger.info("Fill the form details");
		ep.setfName(p.getProperty("FirstName"));
		ep.setlName(p.getProperty("LastName"));
		ep.setEmail(p.getProperty("Email"));
		ep.setPhone(p.getProperty("Phone"));

		ep.orgDropDown(p.getProperty("OrgDrp"));
		ep.setInsType(p.getProperty("InsType"));
		ep.setTitle(p.getProperty("Title"));
		// ep.setCName(p.getProperty("Company"));

		// ep.setRange(p.getProperty("RangeDrp"));
		ep.setNeedMsg(p.getProperty("NeedDrp"));
		ep.setCountry(p.getProperty("CountryDrp"));

		ep.setState(p.getProperty("StateDrp"));
		ep.sbmtButton();
		logger.info("get Error Message");
		ep.getMessage();
		logger.info("*******Testing End*********");
		
	}
	
}


